<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'bookfoxi_cmp');
define('DB_PASSWORD', 'campus@2017');
define('DB_HOST', 'localhost');
define('DB_NAME', 'bookfoxi_campusbox');
?>