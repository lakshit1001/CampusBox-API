<?php

namespace Exception;

class ForbiddenException extends \Exception
{
}
