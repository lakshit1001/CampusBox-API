<?php

namespace Exception;

class NotFoundException extends \Exception
{
}
