<?php

namespace Exception;

class PreconditionFailedException extends \Exception
{
}
